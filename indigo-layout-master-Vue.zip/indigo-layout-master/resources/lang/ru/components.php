<?php

return [
    'filter' => [
        'default' => [
            'sort-by' => 'Сортировка',
            'filter' => 'Фильтр'
        ]
    ]
];
