<?php

return [
    'read_more' => 'More',
    'loading' => 'Loading...',
    'no-internet' => 'Oops! Something went wrong.',
    'wrong-config' => 'Some required parameters have been omitted. See the documentation.',
    'no-data' => 'There is not enough data'
    
];
