<?php

return [
    'filter' => [
        'default' => [
            'sort-by' => 'Sort by',
            'filter' => 'Filter'
        ]
    ]
];
