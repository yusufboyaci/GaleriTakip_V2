export default {
    MODAL_BACK: "Go back",
    MODAL_CLOSE: "Close modal",
    CODE_COPY: "copy",
    CODE_COPIED_MSG: "Text copied to clipboard",
    CONTENT_EMPTY: "No data",
    CONTENT_ERROR: "Error",
    CONTENT_LOADING: "Loading..."
}
