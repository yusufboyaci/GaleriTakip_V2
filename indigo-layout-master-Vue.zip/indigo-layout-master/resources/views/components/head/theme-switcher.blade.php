@if (Cookie::get('theme_dark', 0) == 1) data-dark="true" @endif
